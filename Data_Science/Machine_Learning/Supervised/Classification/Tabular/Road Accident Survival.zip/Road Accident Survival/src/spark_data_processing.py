import os
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, isnan, when, count
from pyspark.sql.types import StructType, StructField, StringType, IntegerType

# Get input path
PATH_DATA = ""

# Create spark session
spark = SparkSession.builder.appName("RoadAccidentSurvivalSession").getOrCreate()

################################## START READ INPUT DATA ##################################
print("Start read input data")
data_schema = StructType([
    StructField("Age", IntegerType(), True),
    StructField("Gender", StringType(), True),
    StructField("Speed_of_Impact", IntegerType(), True),
    StructField("Helmet_Used", StringType(), True),
    StructField("Seatbelt_Used", StringType(), True),
    StructField("Survived", IntegerType(), True)
])

df = spark.read.option("delimiter", ",") \
                .option("header", True) \
                .option("inferSchema", False) \
                .schema(data_schema) \
                .csv(os.path.join(PATH_DATA, "accident.csv"))

print("Finish read input data")
################################## FINISH READ INPUT DATA ##################################

################################## START DATA CLEANING ##################################
print("Start data cleaning")

# Identify missing values
missing_values = df.select([count(when(isnan(c) | col(c).isNull(), c)).alias(c) for c in df.columns])

# Remove missing values for Gender column
df = df.na.drop(subset = ["Gender"])

# Fill missing values for Speed_of_Impact column
median_speed = df.approxQuantile("Speed_of_Impact", [0.5], 0.05)[0]
df = df.na.fill(({"Speed_of_Impact": median_speed}))

print("Finish data cleaning")
################################## FINISH DATA CLEANING ##################################

################################## START SAVE DATA RESULTS ##################################
print("Start save data results")
#df.write.mode("overwrite").saveAsTable("accidents")
df_pandas = df.toPandas()
df_pandas.to_csv(os.path.join(PATH_DATA, "accident_cleaned.csv"), index = False)
print("Finish save data results")
################################## FINISH SAVE DATA RESULTS ##################################
