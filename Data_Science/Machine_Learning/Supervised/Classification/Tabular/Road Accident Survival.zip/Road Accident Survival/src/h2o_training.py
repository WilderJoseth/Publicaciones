import h2o
import os
import pandas as pd
from h2o.automl import H2OAutoML
from sklearn.model_selection import train_test_split

# Get input path
PATH_DATA = ""
target_variable = "Survived"
categorical_features = ["Gender", "Helmet_Used", "Seatbelt_Used"]

print("Start h2o init")
h2o.init()
print("Finish h2o init")

print("Start spliting data")
df = pd.read_csv(os.path.join(PATH_DATA, "accident_cleaned.csv"))

df_train, df_val = train_test_split(df, test_size = 0.2, random_state = 42)
print("df_train shape:", df_train.shape)
print("df_val shape:", df_val.shape)
print("Finish spliting data")

print("Start preparing training data")
df_train_h2o = h2o.H2OFrame(df_train)
df_train_h2o[target_variable] = df_train_h2o[target_variable].asfactor()

for c in categorical_features:
    df_train_h2o[c] = df_train_h2o[c].asfactor()

df_train_h2o.describe()
print("Finish preparing training data")

print("Start preparing validation data")
df_val_h2o = h2o.H2OFrame(df_val)
df_val_h2o[target_variable] = df_val_h2o[target_variable].asfactor()

for c in categorical_features:
    df_val_h2o[c] = df_val_h2o[c].asfactor()

df_val_h2o.describe()
print("Finish preparing validation data")

print("Start training")
x = df_train_h2o.columns
y = target_variable

x.remove(y)

aml = H2OAutoML(max_runtime_secs = 600,
                #exclude_algos =["DeepLearning"],
                seed = 1,
                stopping_metric = "auc",
                sort_metric = "logloss",
                balance_classes = True,
                project_name = "Project_2"
)

aml.train(x = x, y = y, training_frame = df_train_h2o)
print("Finish training")

print("Start validation")
best_model = aml.leader
best_model.model_performance(df_val_h2o)

model_path = h2o.save_model(model = best_model, path = PATH_DATA, force = True)
print(f"Model saved to: {model_path}")
print("Finish validation")
